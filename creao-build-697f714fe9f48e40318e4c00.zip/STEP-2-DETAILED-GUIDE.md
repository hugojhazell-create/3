# Step 2: Push Your Code to GitHub - Detailed Guide

This guide will walk you through **exactly** how to push your TruePath code to GitHub, step by step.

---

## What You're About To Do

You're going to:
1. Create a GitHub account (if you don't have one)
2. Create a new repository on GitHub
3. Connect your local code to that repository
4. Upload (push) your code to GitHub

**Why?** This allows you to:
- Store your code online safely
- Deploy to Vercel/Netlify/Cloudflare
- Share your code
- Track changes over time

---

## Part 1: Create a GitHub Account (If Needed)

### Do you already have a GitHub account?

**✅ If YES:** Skip to Part 2

**❌ If NO:** Follow these steps:

1. **Go to GitHub**
   - Open your web browser
   - Visit: **https://github.com/signup**

2. **Enter your email**
   - Type your email address
   - Click "Continue"

3. **Create a password**
   - Enter a strong password (at least 8 characters)
   - Click "Continue"

4. **Choose a username**
   - This will be your GitHub username
   - Example: "johnsmith" or "sarahdev"
   - **Remember this!** You'll need it later
   - Click "Continue"

5. **Verify you're human**
   - Complete the puzzle/challenge
   - Click "Continue"

6. **Verify your email**
   - Check your email inbox
   - Click the verification link GitHub sent you
   - You're now ready to use GitHub!

---

## Part 2: Create a New Repository on GitHub

Now let's create a place (repository) to store your TruePath code.

### Step-by-Step:

1. **Go to create a new repository**
   - Visit: **https://github.com/new**
   - OR: Click the "+" button at the top-right of GitHub → "New repository"

2. **Fill in the repository details:**

   **Repository name:**
   ```
   truepath
   ```
   (You can use any name, but "truepath" makes sense for this project)

   **Description (optional):**
   ```
   UK CV and LinkedIn optimization platform
   ```

   **Public or Private?**
   - ✅ **Public** - Anyone can see it (recommended for portfolio)
   - ✅ **Private** - Only you can see it (if you want to keep it secret)

   **Choose one - either is fine!**

3. **IMPORTANT: Do NOT check these boxes:**
   - ❌ DO NOT check "Add a README file"
   - ❌ DO NOT check "Add .gitignore"
   - ❌ DO NOT check "Choose a license"

   **Why?** You already have these files in your project!

4. **Click the green "Create repository" button**

---

## Part 3: Copy the Commands GitHub Shows You

After creating the repository, GitHub will show you a page with commands. Here's what to do:

### You'll see a section that says:
**"…or push an existing repository from the command line"**

This section will have commands that look like this:
```bash
git remote add origin https://github.com/YOUR_USERNAME/truepath.git
git branch -M main
git push -u origin main
```

### What These Commands Mean:

1. **`git remote add origin ...`**
   - Connects your local code to GitHub
   - "origin" is just a nickname for your GitHub repository

2. **`git branch -M main`**
   - Renames your branch from "master" to "main"
   - (GitHub prefers "main" as the default branch name)

3. **`git push -u origin main`**
   - Uploads your code to GitHub
   - The `-u` means "remember this for next time"

---

## Part 4: Run the Commands

Now let's actually run these commands to upload your code!

### Option A: Copy GitHub's Commands (Easiest)

1. **On the GitHub page, look for the commands under:**
   "…or push an existing repository from the command line"

2. **The commands will look exactly like this (with YOUR username):**
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/truepath.git
   git branch -M main
   git push -u origin main
   ```

3. **Copy all three commands**
   - Click the copy button (📋) on GitHub, OR
   - Manually select and copy the text

4. **Open your terminal/command line**
   - Make sure you're in the project directory: `/home/user/vite-template`
   - If not, navigate there:
     ```bash
     cd /home/user/vite-template
     ```

5. **Paste and run EACH command ONE AT A TIME:**

   **Command 1:**
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/truepath.git
   ```
   - Press Enter
   - No output is normal - that's good! ✅

   **Command 2:**
   ```bash
   git branch -M main
   ```
   - Press Enter
   - No output is normal - that's good! ✅

   **Command 3:**
   ```bash
   git push -u origin main
   ```
   - Press Enter
   - You'll see output showing your files being uploaded
   - This might take 10-30 seconds

### Option B: Manual Commands (If You Prefer)

If you want to type them yourself, here's the format:

```bash
# Replace YOUR_USERNAME with your actual GitHub username
git remote add origin https://github.com/YOUR_USERNAME/truepath.git

# Rename branch to main
git branch -M main

# Push to GitHub
git push -u origin main
```

**IMPORTANT:** Replace `YOUR_USERNAME` with your actual GitHub username!

**Examples:**
- If your username is "johnsmith": `https://github.com/johnsmith/truepath.git`
- If your username is "sarahcodes": `https://github.com/sarahcodes/truepath.git`

---

## Part 5: What You'll See When Pushing

When you run `git push -u origin main`, you'll see output like this:

```
Enumerating objects: 165, done.
Counting objects: 100% (165/165), done.
Delta compression using up to 8 threads
Compressing objects: 100% (151/151), done.
Writing objects: 100% (165/165), 1.23 MiB | 2.45 MiB/s, done.
Total 165 (delta 12), reused 0 (delta 0)
remote: Resolving deltas: 100% (12/12), done.
To https://github.com/YOUR_USERNAME/truepath.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

**What this means:**
- ✅ Your 159 files are being uploaded
- ✅ Files are compressed to save bandwidth
- ✅ Upload complete!
- ✅ Branch "main" created on GitHub
- ✅ Your local code is now linked to GitHub

---

## Part 6: Verify It Worked

Let's make sure your code is on GitHub:

1. **Go to your repository on GitHub:**
   - Visit: `https://github.com/YOUR_USERNAME/truepath`
   - (Replace YOUR_USERNAME with your actual username)

2. **You should see:**
   - ✅ All your project files listed
   - ✅ "159 commits" or "1 commit" shown
   - ✅ Your commit message: "TruePath - Ready to deploy"
   - ✅ Folders like `src/`, `public/`, files like `package.json`, `README.md`, etc.

3. **If you see all this - SUCCESS!** 🎉

---

## Troubleshooting

### Problem: "Permission denied" or "Authentication failed"

**Solution:** GitHub needs to verify it's really you.

**Option 1 - Use Personal Access Token (Recommended):**

1. Go to: https://github.com/settings/tokens
2. Click "Generate new token" → "Generate new token (classic)"
3. Give it a name: "TruePath Deploy"
4. Check the "repo" box
5. Click "Generate token" at the bottom
6. **COPY THE TOKEN** (you won't see it again!)
7. When running `git push`, use this token as your password

**Option 2 - Use GitHub CLI:**
```bash
# Install GitHub CLI first, then:
gh auth login
# Follow the prompts
```

### Problem: "Repository not found"

**Solution:** Check the URL

1. Make sure you spelled the repository name correctly
2. Make sure your username is correct
3. Try removing and re-adding the remote:
   ```bash
   git remote remove origin
   git remote add origin https://github.com/YOUR_USERNAME/truepath.git
   ```

### Problem: "Branch 'master' already exists"

**Solution:** You're already on the right branch

```bash
# Just rename it to main
git branch -M main

# Then push
git push -u origin main
```

### Problem: "fatal: refusing to merge unrelated histories"

**Solution:** This shouldn't happen with a new repo, but if it does:

```bash
git pull origin main --allow-unrelated-histories
git push -u origin main
```

---

## What Happens Next?

After successfully pushing to GitHub:

1. **Your code is safely stored online** ✅
   - Anyone (if public) can see your code at: `https://github.com/YOUR_USERNAME/truepath`
   - You can clone it on any computer: `git clone https://github.com/YOUR_USERNAME/truepath.git`

2. **You're ready for Step 3: Deploy to Vercel** ✅
   - Vercel can now access your GitHub repository
   - It will automatically build and deploy your website
   - Every time you push updates, Vercel will auto-deploy!

3. **Future updates are easy:**
   ```bash
   # Make changes to your code
   git add .
   git commit -m "Updated features"
   git push
   # Vercel automatically deploys the updates!
   ```

---

## Quick Reference Card

**Save these commands for future use:**

```bash
# Check status
git status

# Add all changes
git add .

# Commit changes
git commit -m "Your message here"

# Push to GitHub
git push

# Pull latest changes
git pull

# View commit history
git log --oneline

# See remote URL
git remote -v
```

---

## Summary of Step 2

Here's what you accomplished:

- ✅ Created GitHub repository (or used existing one)
- ✅ Connected local code to GitHub (`git remote add origin`)
- ✅ Renamed branch to main (`git branch -M main`)
- ✅ Pushed code to GitHub (`git push -u origin main`)
- ✅ Verified code is online at `https://github.com/YOUR_USERNAME/truepath`

**You're now ready for Step 3: Deploy to Vercel!**

---

## Step 3 Preview (What's Next)

Now that your code is on GitHub, deploying to Vercel is super easy:

1. Go to https://vercel.com/signup
2. Click "Continue with GitHub"
3. Import your "truepath" repository
4. Click "Deploy"
5. Wait 2 minutes
6. Your website is LIVE! 🎉

**See QUICKSTART.md for detailed Step 3 instructions!**

---

Need more help? Check these files:
- **START-HERE.md** - Overview
- **QUICKSTART.md** - Full deployment guide
- **DEPLOYMENT.md** - Advanced deployment options
