# Quick Start Guide - Deploy TruePath in 5 Minutes

Follow these steps to get your TruePath website live on the internet.

## Choose Your Deployment Method

### ⚡ Fastest: Vercel (Recommended)

**Time: 5 minutes | Cost: Free**

1. **Create GitHub Account** (if you don't have one)
   - Go to https://github.com/signup
   - Sign up with your email

2. **Upload Your Code to GitHub**

   **Option A: Using Git Command Line**
   ```bash
   # Navigate to your project
   cd /home/user/vite-template

   # Initialize git
   git init
   git add .
   git commit -m "Initial TruePath deployment"

   # Create a new repository on GitHub at https://github.com/new
   # Name it "truepath" and copy the repository URL

   # Connect and push
   git remote add origin https://github.com/YOUR_USERNAME/truepath.git
   git branch -M main
   git push -u origin main
   ```

   **Option B: Using GitHub Desktop (Easier)**
   - Download GitHub Desktop: https://desktop.github.com/
   - Open GitHub Desktop
   - Click "Add" → "Add Existing Repository"
   - Select `/home/user/vite-template` folder
   - Click "Publish Repository"
   - Name it "truepath" and publish

3. **Deploy on Vercel**
   - Go to https://vercel.com/signup
   - Click "Continue with GitHub"
   - Authorize Vercel to access your GitHub
   - Click "Import Project"
   - Select your "truepath" repository
   - Click "Deploy" (Vercel auto-detects settings!)
   - Wait 1-2 minutes...
   - **Done! Your site is live!** 🎉

4. **Get Your Website URL**
   - Vercel will give you a URL like: `https://truepath-xyz123.vercel.app`
   - Share this URL with anyone!
   - Set up custom domain later (optional)

---

### 🚀 Alternative: Netlify

**Time: 5 minutes | Cost: Free**

1. **Upload to GitHub** (same as Vercel steps 1-2 above)

2. **Deploy on Netlify**
   - Go to https://app.netlify.com/signup
   - Sign up with GitHub
   - Click "Add new site" → "Import an existing project"
   - Choose GitHub
   - Select your "truepath" repository
   - Build settings (auto-filled):
     - Build command: `npm run build`
     - Publish directory: `dist`
   - Click "Deploy site"
   - Wait 2-3 minutes...
   - **Done! Your site is live!** 🎉

3. **Your Website URL**
   - `https://truepath-xyz123.netlify.app`

---

### 🌐 Alternative: Cloudflare Pages

**Time: 5 minutes | Cost: Free**

1. **Upload to GitHub** (same as Vercel steps 1-2 above)

2. **Deploy on Cloudflare Pages**
   - Go to https://dash.cloudflare.com/sign-up/pages
   - Sign up with email
   - Connect GitHub account
   - Click "Create a project"
   - Select your repository
   - Build settings:
     - Framework preset: Vite
     - Build command: `npm run build`
     - Build output directory: `dist`
   - Click "Save and Deploy"
   - Wait 2-3 minutes...
   - **Done! Your site is live!** 🎉

3. **Your Website URL**
   - `https://truepath.pages.dev`

---

## What Happens After Deployment?

### Your Live Website Will Have:

✅ **Login/Signup Pages** - Users can create accounts
✅ **CV Builder** - Build professional UK CVs
✅ **CV Optimizer** - ATS scoring and suggestions
✅ **LinkedIn Optimizer** - Profile enhancement
✅ **Apprenticeship Mode** - UK qualification support
✅ **Interview Prep** - STAR method questions
✅ **Subscription Tiers** - Free and Premium (£3/month)
✅ **Mobile Responsive** - Works on all devices
✅ **SSL Certificate** - Secure HTTPS
✅ **Fast Loading** - Optimized performance

### Test Your Website

1. Visit your deployment URL
2. Click "Sign up" to create an account
3. Enter any email and password (mock auth for now)
4. Explore all features:
   - Build a CV
   - Optimize a CV
   - LinkedIn profile tools
   - Apprenticeship support
   - Interview questions

---

## Next Steps After Deployment

### 1. Custom Domain (Optional)

Want `www.truepath.com` instead of the default URL?

**On Vercel:**
- Go to your project → Settings → Domains
- Add your domain
- Update DNS records (instructions provided)
- SSL is automatic

**On Netlify:**
- Go to Site Settings → Domain Management
- Add custom domain
- Follow DNS instructions

**On Cloudflare:**
- Go to Custom Domains
- Add your domain (if on Cloudflare DNS, it's automatic)

### 2. Connect Real Backend

Currently using mock authentication. To connect a real backend:

1. Create backend API (Node.js, Python, etc.)
2. Update `src/lib/auth-context.tsx`:
   ```typescript
   // Replace mock login with:
   const response = await fetch('https://your-api.com/login', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({ email, password })
   });
   ```

### 3. Add Stripe Payments

To charge £3/month for Premium:

1. Sign up at https://stripe.com
2. Get your API keys
3. Add Stripe SDK to your project
4. Create payment flow in your app
5. Use existing subscription tier logic

### 4. Connect Database

Database ORM files are already created in `src/sdk/database/orm/`:
- `orm_user.ts` - User accounts
- `orm_cv.ts` - CV data
- `orm_subscription.ts` - Payments
- `orm_usage_tracking.ts` - Usage limits

Connect to PostgreSQL, MySQL, or any database.

### 5. Add Analytics

**Google Analytics:**
- Create GA4 property
- Add tracking code to `index.html`

**Vercel Analytics (if using Vercel):**
- Enable in project settings (free)

---

## Troubleshooting

**Problem: Build Failed**
- Check build logs in your deployment platform
- Verify all dependencies are in `package.json`
- Try building locally first: `npm run build`

**Problem: Blank Page**
- Open browser console (F12)
- Check for JavaScript errors
- Verify `dist` folder was created correctly

**Problem: 404 on Page Refresh**
- This should work automatically on Vercel/Netlify/Cloudflare
- For manual hosting, configure SPA routing (see DEPLOYMENT.md)

**Problem: Slow Loading**
- Images: Optimize and compress
- Code: Already optimized with Vite
- Use CDN (Vercel/Netlify/Cloudflare have this built-in)

---

## Download Your Code

To download your code from this E2B environment:

### Method 1: Using Git (Recommended)
```bash
# Your code is already in /home/user/vite-template
# Upload to GitHub as shown above
# Then clone anywhere: git clone https://github.com/YOUR_USERNAME/truepath.git
```

### Method 2: Create ZIP
```bash
cd /home/user/vite-template
zip -r truepath.zip . -x "node_modules/*" ".git/*"
# Download the truepath.zip file
```

### Method 3: Copy Files Manually
- Navigate to `/home/user/vite-template`
- Copy all files except `node_modules` folder
- Paste to your local machine
- Run `npm install` to restore dependencies

---

## Support

- **Deployment Issues:** See [DEPLOYMENT.md](./DEPLOYMENT.md)
- **Code Questions:** See [README.md](./README.md)
- **Vercel Docs:** https://vercel.com/docs
- **Netlify Docs:** https://docs.netlify.com
- **Cloudflare Docs:** https://developers.cloudflare.com/pages

---

## Summary

**Deployment Checklist:**

- [ ] Create GitHub account
- [ ] Upload code to GitHub repository
- [ ] Sign up for Vercel/Netlify/Cloudflare
- [ ] Connect GitHub and import repository
- [ ] Click "Deploy"
- [ ] Wait 2-3 minutes
- [ ] Visit your live website URL
- [ ] Test login and features
- [ ] Share your URL! 🎉

**Your TruePath website is now live and ready for users!**

Next: Set up custom domain, connect backend API, add Stripe payments, and launch! 🚀
