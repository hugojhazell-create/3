import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

interface User {
	id: string;
	email: string;
	name: string;
	subscriptionTier: "free" | "paid";
}

interface AuthContextType {
	user: User | null;
	isAuthenticated: boolean;
	isLoading: boolean;
	login: (email: string, password: string) => Promise<boolean>;
	signup: (name: string, email: string, password: string) => Promise<boolean>;
	logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
	const [user, setUser] = useState<User | null>(null);
	const [isLoading, setIsLoading] = useState(true);

	// Check for existing session on mount
	useEffect(() => {
		const storedUser = localStorage.getItem("truepath_user");
		if (storedUser) {
			try {
				setUser(JSON.parse(storedUser));
			} catch (error) {
				localStorage.removeItem("truepath_user");
			}
		}
		setIsLoading(false);
	}, []);

	const login = async (email: string, password: string): Promise<boolean> => {
		try {
			// Simulate API call - in production, this would call your backend
			// For demo purposes, we'll accept any email/password combination
			await new Promise((resolve) => setTimeout(resolve, 1000));

			// Create mock user
			const mockUser: User = {
				id: `user_${Date.now()}`,
				email,
				name: email.split("@")[0],
				subscriptionTier: "free",
			};

			setUser(mockUser);
			localStorage.setItem("truepath_user", JSON.stringify(mockUser));
			return true;
		} catch (error) {
			return false;
		}
	};

	const signup = async (
		name: string,
		email: string,
		password: string
	): Promise<boolean> => {
		try {
			// Simulate API call - in production, this would call your backend
			await new Promise((resolve) => setTimeout(resolve, 1000));

			// Create new user
			const newUser: User = {
				id: `user_${Date.now()}`,
				email,
				name,
				subscriptionTier: "free",
			};

			setUser(newUser);
			localStorage.setItem("truepath_user", JSON.stringify(newUser));
			return true;
		} catch (error) {
			return false;
		}
	};

	const logout = () => {
		setUser(null);
		localStorage.removeItem("truepath_user");
	};

	return (
		<AuthContext.Provider
			value={{
				user,
				isAuthenticated: !!user,
				isLoading,
				login,
				signup,
				logout,
			}}
		>
			{children}
		</AuthContext.Provider>
	);
}

export function useAuth() {
	const context = useContext(AuthContext);
	if (context === undefined) {
		throw new Error("useAuth must be used within an AuthProvider");
	}
	return context;
}
