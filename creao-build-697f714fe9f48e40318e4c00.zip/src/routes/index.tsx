import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { FileText, Sparkles, Linkedin, GraduationCap, MessageSquare, Download, Upload, CheckCircle2, AlertCircle, TrendingUp, Target, Award, Loader2, LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/")({
	component: App,
});

type SubscriptionTier = "free" | "paid";
type CVTemplate = "Student/Graduate" | "Professional" | "Career Changer" | "Apprenticeship";
type CareerLevel = "entry" | "junior" | "mid" | "senior" | "apprentice";
type AuthView = "login" | "signup";

interface WorkExperience {
	company: string;
	role: string;
	startDate: string;
	endDate: string;
	bulletPoints: string[];
}

interface Education {
	institution: string;
	qualification: string;
	startDate: string;
	endDate: string;
}

interface CVData {
	template: CVTemplate;
	careerLevel: CareerLevel;
	targetRole: string;
	personalProfile: string;
	skills: string[];
	experience: WorkExperience[];
	education: Education[];
	certifications: string[];
	projects: string[];
	ukQualifications: {
		gcses?: string;
		aLevels?: string;
		btecs?: string;
		tLevels?: string;
	};
}

interface OptimizationResult {
	score: number;
	keywordMatch: number;
	suggestions: string[];
	optimizedContent: string;
}

function App() {
	const { user, isAuthenticated, isLoading: authLoading, login, signup, logout } = useAuth();
	const [authView, setAuthView] = useState<AuthView>("login");
	const [activeView, setActiveView] = useState<"landing" | "builder" | "optimizer" | "linkedin" | "apprenticeship" | "interview">("landing");
	const [subscriptionTier, setSubscriptionTier] = useState<SubscriptionTier>("free");
	const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);

	// Auth form state
	const [loginEmail, setLoginEmail] = useState("");
	const [loginPassword, setLoginPassword] = useState("");
	const [signupName, setSignupName] = useState("");
	const [signupEmail, setSignupEmail] = useState("");
	const [signupPassword, setSignupPassword] = useState("");
	const [signupConfirmPassword, setSignupConfirmPassword] = useState("");
	const [authError, setAuthError] = useState("");
	const [authIsLoading, setAuthIsLoading] = useState(false);

	// Usage tracking for free tier
	const [usageStats, setUsageStats] = useState({
		cvBuilds: 0,
		cvOptimizations: 0,
		linkedinOptimizations: 0,
		interviewQuestions: 0,
	});

	// CV Builder state
	const [cvData, setCVData] = useState<CVData>({
		template: "Professional",
		careerLevel: "mid",
		targetRole: "",
		personalProfile: "",
		skills: [],
		experience: [],
		education: [],
		certifications: [],
		projects: [],
		ukQualifications: {},
	});

	const [newSkill, setNewSkill] = useState("");
	const [optimizationResult, setOptimizationResult] = useState<OptimizationResult | null>(null);
	const [jobDescription, setJobDescription] = useState("");
	const [uploadedCV, setUploadedCV] = useState("");

	// LinkedIn state
	const [linkedinData, setLinkedinData] = useState({
		headline: "",
		about: "",
		experience: "",
	});

	// Interview prep state
	const [interviewQuestions, setInterviewQuestions] = useState<string[]>([]);

	// Sync subscription tier with user data
	useEffect(() => {
		if (user) {
			setSubscriptionTier(user.subscriptionTier);
		}
	}, [user]);

	const handleLogin = async (e: React.FormEvent) => {
		e.preventDefault();
		setAuthError("");
		setAuthIsLoading(true);

		try {
			if (!loginEmail || !loginPassword) {
				setAuthError("Please fill in all fields");
				setAuthIsLoading(false);
				return;
			}

			if (!loginEmail.includes("@")) {
				setAuthError("Please enter a valid email address");
				setAuthIsLoading(false);
				return;
			}

			const success = await login(loginEmail, loginPassword);

			if (!success) {
				setAuthError("Invalid email or password");
			}
		} catch (err) {
			setAuthError("An error occurred. Please try again.");
		} finally {
			setAuthIsLoading(false);
		}
	};

	const handleSignup = async (e: React.FormEvent) => {
		e.preventDefault();
		setAuthError("");
		setAuthIsLoading(true);

		try {
			if (!signupName || !signupEmail || !signupPassword || !signupConfirmPassword) {
				setAuthError("Please fill in all fields");
				setAuthIsLoading(false);
				return;
			}

			if (!signupEmail.includes("@")) {
				setAuthError("Please enter a valid email address");
				setAuthIsLoading(false);
				return;
			}

			if (signupPassword.length < 6) {
				setAuthError("Password must be at least 6 characters");
				setAuthIsLoading(false);
				return;
			}

			if (signupPassword !== signupConfirmPassword) {
				setAuthError("Passwords do not match");
				setAuthIsLoading(false);
				return;
			}

			const success = await signup(signupName, signupEmail, signupPassword);

			if (!success) {
				setAuthError("Failed to create account. Please try again.");
			}
		} catch (err) {
			setAuthError("An error occurred. Please try again.");
		} finally {
			setAuthIsLoading(false);
		}
	};

	const checkFreeLimit = (feature: keyof typeof usageStats, limit: number) => {
		if (subscriptionTier === "paid") return true;
		if (usageStats[feature] >= limit) {
			setShowUpgradeDialog(true);
			return false;
		}
		return true;
	};

	const incrementUsage = (feature: keyof typeof usageStats) => {
		if (subscriptionTier === "free") {
			setUsageStats(prev => ({ ...prev, [feature]: prev[feature] + 1 }));
		}
	};

	const handleBuildCV = () => {
		if (!checkFreeLimit("cvBuilds", 1)) return;
		incrementUsage("cvBuilds");
		alert("CV built successfully! In production, this would generate a PDF.");
	};

	const handleOptimizeCV = () => {
		if (!checkFreeLimit("cvOptimizations", 1)) return;
		incrementUsage("cvOptimizations");

		const mockResult: OptimizationResult = {
			score: 78,
			keywordMatch: 65,
			suggestions: [
				"Add more action verbs like 'delivered', 'implemented', 'managed'",
				"Include specific metrics and achievements where possible",
				"Align experience descriptions with job requirements",
				"Use British English spelling (e.g., 'organised' not 'organized')",
				"Add relevant industry keywords from the job description",
			],
			optimizedContent: `Improved version:\n\n• Delivered high-impact solutions that increased efficiency by 25%\n• Implemented robust systems reducing processing time by 30%\n• Managed cross-functional teams of 8+ members across UK operations\n• Organised quarterly stakeholder reviews with C-level executives`,
		};

		setOptimizationResult(mockResult);
	};

	const handleOptimizeLinkedIn = () => {
		if (subscriptionTier === "free" && usageStats.linkedinOptimizations >= 1) {
			setShowUpgradeDialog(true);
			return;
		}
		incrementUsage("linkedinOptimizations");
		alert("LinkedIn profile optimised! Check the preview below.");
	};

	const handleGenerateInterviewQuestions = () => {
		if (!checkFreeLimit("interviewQuestions", 5)) return;
		incrementUsage("interviewQuestions");

		const mockQuestions = [
			"Tell me about yourself and your background.",
			"Why are you interested in this role at our company?",
			"Describe a time when you faced a significant challenge at work. How did you handle it?",
			"What are your greatest strengths and how do they apply to this position?",
			"Where do you see yourself in five years?",
			"Can you give an example of when you worked effectively in a team?",
			"How do you prioritise tasks when managing multiple deadlines?",
			"What relevant skills and experience make you suitable for this apprenticeship?",
		];

		const limit = subscriptionTier === "free" ? 5 : mockQuestions.length;
		setInterviewQuestions(mockQuestions.slice(0, limit));
	};

	const addSkill = () => {
		if (newSkill.trim()) {
			setCVData(prev => ({ ...prev, skills: [...prev.skills, newSkill.trim()] }));
			setNewSkill("");
		}
	};

	const removeSkill = (index: number) => {
		setCVData(prev => ({ ...prev, skills: prev.skills.filter((_, i) => i !== index) }));
	};

	// Show loading state while checking auth
	if (authLoading) {
		return (
			<div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-zinc-950 dark:to-zinc-900 flex items-center justify-center">
				<div className="text-center">
					<Loader2 className="size-12 animate-spin mx-auto mb-4 text-primary" />
					<p className="text-muted-foreground">Loading...</p>
				</div>
			</div>
		);
	}

	// Show auth pages if not authenticated
	if (!isAuthenticated) {
		return (
			<div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-zinc-950 dark:to-zinc-900 flex items-center justify-center p-4">
				<div className="w-full max-w-md">
					{/* Logo */}
					<div className="flex justify-center mb-8">
						<div className="flex items-center gap-2">
							<Target className="size-10 text-primary" />
							<h1 className="text-3xl font-bold">TruePath</h1>
						</div>
					</div>

					{authView === "login" ? (
						// Login Card
						<Card>
							<CardHeader>
								<CardTitle className="text-2xl">Welcome back</CardTitle>
								<CardDescription>
									Sign in to your account to continue
								</CardDescription>
							</CardHeader>
							<CardContent>
								<form onSubmit={handleLogin} className="space-y-4">
									{authError && (
										<Alert variant="destructive">
											<AlertCircle className="size-4" />
											<AlertDescription>{authError}</AlertDescription>
										</Alert>
									)}

									<div className="space-y-2">
										<Label htmlFor="email">Email</Label>
										<Input
											id="email"
											type="email"
											placeholder="your.email@example.com"
											value={loginEmail}
											onChange={(e) => setLoginEmail(e.target.value)}
											disabled={authIsLoading}
											autoComplete="email"
										/>
									</div>

									<div className="space-y-2">
										<Label htmlFor="password">Password</Label>
										<Input
											id="password"
											type="password"
											placeholder="Enter your password"
											value={loginPassword}
											onChange={(e) => setLoginPassword(e.target.value)}
											disabled={authIsLoading}
											autoComplete="current-password"
										/>
									</div>

									<div className="flex items-center justify-between">
										<button
											type="button"
											className="text-sm text-primary hover:underline"
											onClick={() => alert("Password reset functionality coming soon!")}
										>
											Forgot password?
										</button>
									</div>

									<Button
										type="submit"
										className="w-full"
										disabled={authIsLoading}
									>
										{authIsLoading ? (
											<>
												<Loader2 className="mr-2 size-4 animate-spin" />
												Signing in...
											</>
										) : (
											"Sign in"
										)}
									</Button>
								</form>

								<div className="mt-6 text-center text-sm">
									<span className="text-muted-foreground">
										Don't have an account?{" "}
									</span>
									<button
										type="button"
										className="text-primary hover:underline font-medium"
										onClick={() => { setAuthView("signup"); setAuthError(""); }}
									>
										Sign up
									</button>
								</div>
							</CardContent>
						</Card>
					) : (
						// Signup Card
						<Card>
							<CardHeader>
								<CardTitle className="text-2xl">Create your account</CardTitle>
								<CardDescription>
									Get started with TruePath today
								</CardDescription>
							</CardHeader>
							<CardContent>
								<form onSubmit={handleSignup} className="space-y-4">
									{authError && (
										<Alert variant="destructive">
											<AlertCircle className="size-4" />
											<AlertDescription>{authError}</AlertDescription>
										</Alert>
									)}

									<div className="space-y-2">
										<Label htmlFor="name">Full Name</Label>
										<Input
											id="name"
											type="text"
											placeholder="John Smith"
											value={signupName}
											onChange={(e) => setSignupName(e.target.value)}
											disabled={authIsLoading}
											autoComplete="name"
										/>
									</div>

									<div className="space-y-2">
										<Label htmlFor="signup-email">Email</Label>
										<Input
											id="signup-email"
											type="email"
											placeholder="your.email@example.com"
											value={signupEmail}
											onChange={(e) => setSignupEmail(e.target.value)}
											disabled={authIsLoading}
											autoComplete="email"
										/>
									</div>

									<div className="space-y-2">
										<Label htmlFor="signup-password">Password</Label>
										<Input
											id="signup-password"
											type="password"
											placeholder="Create a password (min 6 characters)"
											value={signupPassword}
											onChange={(e) => setSignupPassword(e.target.value)}
											disabled={authIsLoading}
											autoComplete="new-password"
										/>
									</div>

									<div className="space-y-2">
										<Label htmlFor="confirm-password">Confirm Password</Label>
										<Input
											id="confirm-password"
											type="password"
											placeholder="Confirm your password"
											value={signupConfirmPassword}
											onChange={(e) => setSignupConfirmPassword(e.target.value)}
											disabled={authIsLoading}
											autoComplete="new-password"
										/>
									</div>

									<Button
										type="submit"
										className="w-full"
										disabled={authIsLoading}
									>
										{authIsLoading ? (
											<>
												<Loader2 className="mr-2 size-4 animate-spin" />
												Creating account...
											</>
										) : (
											"Create account"
										)}
									</Button>
								</form>

								<div className="mt-6 text-center text-sm">
									<span className="text-muted-foreground">
										Already have an account?{" "}
									</span>
									<button
										type="button"
										className="text-primary hover:underline font-medium"
										onClick={() => { setAuthView("login"); setAuthError(""); }}
									>
										Sign in
									</button>
								</div>
							</CardContent>
						</Card>
					)}

					<p className="text-center text-sm text-muted-foreground mt-8">
						By continuing, you agree to our Terms of Service and Privacy Policy
					</p>
				</div>
			</div>
		);
	}

	// Main app for authenticated users
	if (activeView === "landing") {
		return (
			<div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white dark:from-zinc-950 dark:to-zinc-900">
				{/* Header */}
				<header className="border-b bg-white/50 dark:bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
					<div className="container mx-auto px-4 py-4 flex justify-between items-center">
						<div className="flex items-center gap-2">
							<Target className="size-8 text-primary" />
							<h1 className="text-2xl font-bold">TruePath</h1>
						</div>
						<div className="flex items-center gap-4">
							<span className="text-sm text-muted-foreground hidden sm:inline">
								Welcome, {user?.name}!
							</span>
							<Badge variant={subscriptionTier === "paid" ? "default" : "secondary"}>
								{subscriptionTier === "paid" ? "Premium Member" : "Free Tier"}
							</Badge>
							{subscriptionTier === "free" && (
								<Button onClick={() => setSubscriptionTier("paid")} size="sm">
									Upgrade to £3/month
								</Button>
							)}
							<Button onClick={logout} variant="ghost" size="sm">
								<LogOut className="size-4" />
							</Button>
						</div>
					</div>
				</header>

				{/* Hero Section */}
				<section className="container mx-auto px-4 py-16 text-center">
					<h2 className="text-4xl md:text-6xl font-bold mb-6">
						Build Your Career Path with Confidence
					</h2>
					<p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
						UK-focused CV and LinkedIn optimization platform with specialist apprenticeship support.
						Create ATS-friendly CVs, optimise your profile, and ace your interviews.
					</p>
					<div className="flex gap-4 justify-center flex-wrap">
						<Button size="lg" onClick={() => setActiveView("builder")}>
							<FileText className="mr-2" />
							Build CV
						</Button>
						<Button size="lg" variant="outline" onClick={() => setActiveView("optimizer")}>
							<Sparkles className="mr-2" />
							Optimise CV
						</Button>
					</div>
				</section>

				{/* Features Grid */}
				<section className="container mx-auto px-4 py-16">
					<h3 className="text-3xl font-bold text-center mb-12">Everything You Need to Succeed</h3>
					<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
						<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveView("builder")}>
							<CardHeader>
								<FileText className="size-12 mb-4 text-primary" />
								<CardTitle>UK CV Builder</CardTitle>
								<CardDescription>
									Step-by-step builder with 4 UK-standard templates. ATS-friendly, no photos or personal data.
								</CardDescription>
							</CardHeader>
						</Card>

						<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveView("optimizer")}>
							<CardHeader>
								<Sparkles className="size-12 mb-4 text-primary" />
								<CardTitle>CV Optimiser</CardTitle>
								<CardDescription>
									Get ATS compatibility scores, keyword matching, and AI-powered improvement suggestions.
								</CardDescription>
							</CardHeader>
						</Card>

						<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveView("linkedin")}>
							<CardHeader>
								<Linkedin className="size-12 mb-4 text-primary" />
								<CardTitle>LinkedIn Optimiser</CardTitle>
								<CardDescription>
									Optimise your headline, about section, and experience for UK professional standards.
								</CardDescription>
							</CardHeader>
						</Card>

						<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveView("apprenticeship")}>
							<CardHeader>
								<GraduationCap className="size-12 mb-4 text-primary" />
								<CardTitle>Apprenticeship Mode</CardTitle>
								<CardDescription>
									Specialist support for apprenticeships with qualification translation and application help.
								</CardDescription>
							</CardHeader>
						</Card>

						<Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveView("interview")}>
							<CardHeader>
								<MessageSquare className="size-12 mb-4 text-primary" />
								<CardTitle>Interview Prep</CardTitle>
								<CardDescription>
									UK-style interview questions with STAR method guidance and example talking points.
								</CardDescription>
							</CardHeader>
						</Card>

						<Card className="bg-primary text-primary-foreground">
							<CardHeader>
								<Award className="size-12 mb-4" />
								<CardTitle>Premium Features</CardTitle>
								<CardDescription className="text-primary-foreground/80">
									£3/month for unlimited access to all features, exports, and optimisations.
								</CardDescription>
							</CardHeader>
						</Card>
					</div>
				</section>

				{/* Pricing Section */}
				<section className="container mx-auto px-4 py-16">
					<h3 className="text-3xl font-bold text-center mb-12">Simple, Transparent Pricing</h3>
					<div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
						<Card>
							<CardHeader>
								<CardTitle>Free Tier</CardTitle>
								<CardDescription>Perfect for getting started</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<ul className="space-y-2 text-sm">
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										1 CV build
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Basic CV optimisation tips
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										1 LinkedIn headline
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										5 interview questions
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Limited apprenticeship mode
									</li>
								</ul>
							</CardContent>
						</Card>

						<Card className="border-primary shadow-lg">
							<CardHeader>
								<Badge className="w-fit mb-2">Recommended</Badge>
								<CardTitle>Premium - £3/month</CardTitle>
								<CardDescription>Full access to everything</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<ul className="space-y-2 text-sm">
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Unlimited CV builds & optimisation
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Full LinkedIn optimisation
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Complete apprenticeship mode
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										Unlimited interview prep
									</li>
									<li className="flex items-center gap-2">
										<CheckCircle2 className="size-4 text-green-600" />
										PDF exports & downloads
									</li>
								</ul>
								<Button className="w-full" onClick={() => setSubscriptionTier("paid")}>
									Upgrade Now
								</Button>
							</CardContent>
						</Card>
					</div>
				</section>
			</div>
		);
	}

	return (
		<div className="min-h-screen bg-zinc-50 dark:bg-zinc-950">
			{/* Navigation Header */}
			<header className="border-b bg-white dark:bg-zinc-900 sticky top-0 z-50">
				<div className="container mx-auto px-4 py-4">
					<div className="flex justify-between items-center mb-4">
						<div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveView("landing")}>
							<Target className="size-6 text-primary" />
							<h1 className="text-xl font-bold">TruePath</h1>
						</div>
						<div className="flex items-center gap-3">
							<span className="text-sm text-muted-foreground hidden sm:inline">
								{user?.name}
							</span>
							<Badge variant={subscriptionTier === "paid" ? "default" : "secondary"}>
								{subscriptionTier === "paid" ? "Premium" : "Free"}
							</Badge>
							<Button onClick={logout} variant="ghost" size="sm">
								<LogOut className="size-4" />
							</Button>
						</div>
					</div>
					<nav className="flex gap-2 flex-wrap">
						<Button variant={activeView === "builder" ? "default" : "ghost"} size="sm" onClick={() => setActiveView("builder")}>
							<FileText className="mr-2 size-4" />
							Build CV
						</Button>
						<Button variant={activeView === "optimizer" ? "default" : "ghost"} size="sm" onClick={() => setActiveView("optimizer")}>
							<Sparkles className="mr-2 size-4" />
							Optimise
						</Button>
						<Button variant={activeView === "linkedin" ? "default" : "ghost"} size="sm" onClick={() => setActiveView("linkedin")}>
							<Linkedin className="mr-2 size-4" />
							LinkedIn
						</Button>
						<Button variant={activeView === "apprenticeship" ? "default" : "ghost"} size="sm" onClick={() => setActiveView("apprenticeship")}>
							<GraduationCap className="mr-2 size-4" />
							Apprenticeship
						</Button>
						<Button variant={activeView === "interview" ? "default" : "ghost"} size="sm" onClick={() => setActiveView("interview")}>
							<MessageSquare className="mr-2 size-4" />
							Interview Prep
						</Button>
					</nav>
				</div>
			</header>

			<main className="container mx-auto px-4 py-8">
				{/* CV Builder */}
				{activeView === "builder" && (
					<div className="max-w-4xl mx-auto space-y-6">
						<div>
							<h2 className="text-3xl font-bold mb-2">UK CV Builder</h2>
							<p className="text-muted-foreground">Create a professional, ATS-friendly CV tailored to UK standards</p>
						</div>

						<Card>
							<CardHeader>
								<CardTitle>Template & Career Level</CardTitle>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="grid md:grid-cols-2 gap-4">
									<div className="space-y-2">
										<Label>CV Template</Label>
										<Select value={cvData.template} onValueChange={(value) => setCVData(prev => ({ ...prev, template: value as CVTemplate }))}>
											<SelectTrigger>
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="Student/Graduate">Student/Graduate</SelectItem>
												<SelectItem value="Professional">Professional</SelectItem>
												<SelectItem value="Career Changer">Career Changer</SelectItem>
												<SelectItem value="Apprenticeship">Apprenticeship</SelectItem>
											</SelectContent>
										</Select>
									</div>
									<div className="space-y-2">
										<Label>Career Level</Label>
										<Select value={cvData.careerLevel} onValueChange={(value) => setCVData(prev => ({ ...prev, careerLevel: value as CareerLevel }))}>
											<SelectTrigger>
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="entry">Entry Level</SelectItem>
												<SelectItem value="junior">Junior</SelectItem>
												<SelectItem value="mid">Mid-Level</SelectItem>
												<SelectItem value="senior">Senior</SelectItem>
												<SelectItem value="apprentice">Apprentice</SelectItem>
											</SelectContent>
										</Select>
									</div>
								</div>

								<div className="space-y-2">
									<Label>Target Role</Label>
									<Input placeholder="e.g. Software Developer, Marketing Assistant" value={cvData.targetRole} onChange={(e) => setCVData(prev => ({ ...prev, targetRole: e.target.value }))} />
								</div>
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Personal Profile</CardTitle>
								<CardDescription>A brief summary highlighting your key strengths and career goals</CardDescription>
							</CardHeader>
							<CardContent>
								<Textarea placeholder="Write a compelling 3-4 sentence summary about yourself..." rows={4} value={cvData.personalProfile} onChange={(e) => setCVData(prev => ({ ...prev, personalProfile: e.target.value }))} />
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Skills</CardTitle>
								<CardDescription>Add relevant skills for your target role</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="flex gap-2">
									<Input placeholder="Add a skill..." value={newSkill} onChange={(e) => setNewSkill(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())} />
									<Button onClick={addSkill}>Add</Button>
								</div>
								<div className="flex flex-wrap gap-2">
									{cvData.skills.map((skill, index) => (
										<Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeSkill(index)}>
											{skill} ×
										</Badge>
									))}
								</div>
							</CardContent>
						</Card>

						<div className="flex gap-4">
							<Button onClick={handleBuildCV} className="flex-1">
								<Download className="mr-2" />
								Build & Download CV
							</Button>
							<Button variant="outline" onClick={() => setActiveView("optimizer")}>
								Optimise This CV
							</Button>
						</div>

						{subscriptionTier === "free" && usageStats.cvBuilds >= 1 && (
							<Card className="border-amber-500">
								<CardContent className="pt-6">
									<div className="flex items-start gap-3">
										<AlertCircle className="size-5 text-amber-500 mt-0.5" />
										<div>
											<p className="font-medium">Free tier limit reached</p>
											<p className="text-sm text-muted-foreground">You've used your 1 free CV build. Upgrade to Premium for unlimited access.</p>
										</div>
									</div>
								</CardContent>
							</Card>
						)}
					</div>
				)}

				{/* CV Optimizer */}
				{activeView === "optimizer" && (
					<div className="max-w-4xl mx-auto space-y-6">
						<div>
							<h2 className="text-3xl font-bold mb-2">CV Optimiser</h2>
							<p className="text-muted-foreground">Get ATS compatibility scores and improvement suggestions</p>
						</div>

						<Card>
							<CardHeader>
								<CardTitle>Upload or Paste Your CV</CardTitle>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="border-2 border-dashed rounded-lg p-8 text-center">
									<Upload className="size-12 mx-auto mb-4 text-muted-foreground" />
									<p className="text-sm text-muted-foreground mb-4">Upload your CV or paste the text below</p>
									<Button variant="outline">
										<Upload className="mr-2" />
										Upload PDF
									</Button>
								</div>
								<Textarea placeholder="Or paste your CV text here..." rows={6} value={uploadedCV} onChange={(e) => setUploadedCV(e.target.value)} />
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Job Description</CardTitle>
								<CardDescription>Paste the job or apprenticeship description to optimize against</CardDescription>
							</CardHeader>
							<CardContent>
								<Textarea placeholder="Paste the job description here..." rows={6} value={jobDescription} onChange={(e) => setJobDescription(e.target.value)} />
							</CardContent>
						</Card>

						<Button onClick={handleOptimizeCV} className="w-full">
							<Sparkles className="mr-2" />
							Analyse & Optimise CV
						</Button>

						{optimizationResult && (
							<>
								<Card>
									<CardHeader>
										<CardTitle>ATS Compatibility Score</CardTitle>
									</CardHeader>
									<CardContent className="space-y-4">
										<div>
											<div className="flex justify-between mb-2">
												<span className="font-medium">Overall Score</span>
												<span className="font-bold text-lg">{optimizationResult.score}%</span>
											</div>
											<Progress value={optimizationResult.score} className="h-3" />
										</div>
										<div>
											<div className="flex justify-between mb-2">
												<span className="font-medium">Keyword Match</span>
												<span className="font-bold text-lg">{optimizationResult.keywordMatch}%</span>
											</div>
											<Progress value={optimizationResult.keywordMatch} className="h-3" />
										</div>
									</CardContent>
								</Card>

								<Card>
									<CardHeader>
										<CardTitle>Improvement Suggestions</CardTitle>
									</CardHeader>
									<CardContent>
										<ul className="space-y-2">
											{optimizationResult.suggestions.map((suggestion, index) => (
												<li key={index} className="flex gap-3">
													<TrendingUp className="size-5 text-primary shrink-0 mt-0.5" />
													<span className="text-sm">{suggestion}</span>
												</li>
											))}
										</ul>
									</CardContent>
								</Card>

								<Card>
									<CardHeader>
										<CardTitle>Optimised Content</CardTitle>
									</CardHeader>
									<CardContent>
										<pre className="whitespace-pre-wrap text-sm bg-muted p-4 rounded-lg">{optimizationResult.optimizedContent}</pre>
									</CardContent>
								</Card>
							</>
						)}
					</div>
				)}

				{/* LinkedIn Optimizer */}
				{activeView === "linkedin" && (
					<div className="max-w-4xl mx-auto space-y-6">
						<div>
							<h2 className="text-3xl font-bold mb-2">LinkedIn Profile Optimiser</h2>
							<p className="text-muted-foreground">Optimise your LinkedIn presence for UK professional standards</p>
						</div>

						<Card>
							<CardHeader>
								<CardTitle>Headline</CardTitle>
								<CardDescription>Your professional title and value proposition (220 characters max)</CardDescription>
							</CardHeader>
							<CardContent>
								<Input placeholder="e.g. Software Developer | React & TypeScript Specialist | Building User-Centric Web Applications" value={linkedinData.headline} onChange={(e) => setLinkedinData(prev => ({ ...prev, headline: e.target.value }))} maxLength={220} />
								<p className="text-xs text-muted-foreground mt-2">{linkedinData.headline.length}/220 characters</p>
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>About Section</CardTitle>
								<CardDescription>Tell your professional story (2,000 characters max)</CardDescription>
							</CardHeader>
							<CardContent>
								<Textarea placeholder="Write about your background, skills, and what you're passionate about..." rows={8} value={linkedinData.about} onChange={(e) => setLinkedinData(prev => ({ ...prev, about: e.target.value }))} maxLength={2000} />
								<p className="text-xs text-muted-foreground mt-2">{linkedinData.about.length}/2,000 characters</p>
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Experience Description</CardTitle>
								<CardDescription>Optimise your current or most recent role description</CardDescription>
							</CardHeader>
							<CardContent>
								<Textarea placeholder="Describe your responsibilities and achievements..." rows={6} value={linkedinData.experience} onChange={(e) => setLinkedinData(prev => ({ ...prev, experience: e.target.value }))} />
							</CardContent>
						</Card>

						<Button onClick={handleOptimizeLinkedIn} className="w-full">
							<Sparkles className="mr-2" />
							Optimise LinkedIn Profile
						</Button>
					</div>
				)}

				{/* Apprenticeship Mode */}
				{activeView === "apprenticeship" && (
					<div className="max-w-4xl mx-auto space-y-6">
						<div>
							<h2 className="text-3xl font-bold mb-2">Apprenticeship Mode</h2>
							<p className="text-muted-foreground">Specialist support for apprenticeship applications</p>
						</div>

						<Card>
							<CardHeader>
								<CardTitle>UK Qualifications</CardTitle>
								<CardDescription>Translate your GCSEs, A-Levels, BTECs, or T Levels into employer-friendly skills</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="space-y-2">
									<Label>GCSEs</Label>
									<Input placeholder="e.g. Maths (7), English (6), Science (6)" value={cvData.ukQualifications.gcses || ""} onChange={(e) => setCVData(prev => ({ ...prev, ukQualifications: { ...prev.ukQualifications, gcses: e.target.value } }))} />
								</div>
								<div className="space-y-2">
									<Label>A-Levels</Label>
									<Input placeholder="e.g. Computer Science (B), Mathematics (A)" value={cvData.ukQualifications.aLevels || ""} onChange={(e) => setCVData(prev => ({ ...prev, ukQualifications: { ...prev.ukQualifications, aLevels: e.target.value } }))} />
								</div>
								<div className="space-y-2">
									<Label>BTECs</Label>
									<Input placeholder="e.g. Level 3 Extended Diploma in IT (Distinction)" value={cvData.ukQualifications.btecs || ""} onChange={(e) => setCVData(prev => ({ ...prev, ukQualifications: { ...prev.ukQualifications, btecs: e.target.value } }))} />
								</div>
								<div className="space-y-2">
									<Label>T Levels</Label>
									<Input placeholder="e.g. T Level in Digital Production, Design and Development" value={cvData.ukQualifications.tLevels || ""} onChange={(e) => setCVData(prev => ({ ...prev, ukQualifications: { ...prev.ukQualifications, tLevels: e.target.value } }))} />
								</div>
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Transferable Skills</CardTitle>
								<CardDescription>Highlight skills from projects, volunteering, and part-time work</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<Textarea placeholder="Describe any projects, volunteering, or part-time work that demonstrates relevant skills..." rows={6} />
								<div className="bg-muted p-4 rounded-lg">
									<h4 className="font-medium mb-2">Suggested Skills to Highlight:</h4>
									<ul className="text-sm space-y-1">
										<li>• Teamwork and collaboration</li>
										<li>• Communication and presentation skills</li>
										<li>• Problem-solving and analytical thinking</li>
										<li>• Time management and organisation</li>
										<li>• Initiative and self-motivation</li>
									</ul>
								</div>
							</CardContent>
						</Card>

						<Card>
							<CardHeader>
								<CardTitle>Application Questions</CardTitle>
								<CardDescription>Get help with common apprenticeship application questions</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<div>
									<Label className="text-base mb-2 block">Why this apprenticeship?</Label>
									<Textarea placeholder="Draft your answer here..." rows={4} />
									<p className="text-xs text-muted-foreground mt-2">Focus on: Your genuine interest, how it aligns with your career goals, what you hope to learn</p>
								</div>
								<Separator />
								<div>
									<Label className="text-base mb-2 block">What skills can you bring?</Label>
									<Textarea placeholder="Draft your answer here..." rows={4} />
									<p className="text-xs text-muted-foreground mt-2">Include: Relevant coursework, projects, soft skills, enthusiasm to learn</p>
								</div>
							</CardContent>
						</Card>
					</div>
				)}

				{/* Interview Prep */}
				{activeView === "interview" && (
					<div className="max-w-4xl mx-auto space-y-6">
						<div>
							<h2 className="text-3xl font-bold mb-2">Interview Preparation Assistant</h2>
							<p className="text-muted-foreground">Practice with UK-style interview questions and STAR method guidance</p>
						</div>

						<Card>
							<CardHeader>
								<CardTitle>Generate Interview Questions</CardTitle>
								<CardDescription>Get personalised questions based on your role and experience level</CardDescription>
							</CardHeader>
							<CardContent className="space-y-4">
								<div className="grid md:grid-cols-2 gap-4">
									<div className="space-y-2">
										<Label>Role Type</Label>
										<Select defaultValue="general">
											<SelectTrigger>
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="general">General Questions</SelectItem>
												<SelectItem value="technical">Technical Role</SelectItem>
												<SelectItem value="apprenticeship">Apprenticeship</SelectItem>
												<SelectItem value="graduate">Graduate Role</SelectItem>
											</SelectContent>
										</Select>
									</div>
									<div className="space-y-2">
										<Label>Experience Level</Label>
										<Select defaultValue="entry">
											<SelectTrigger>
												<SelectValue />
											</SelectTrigger>
											<SelectContent>
												<SelectItem value="entry">Entry Level</SelectItem>
												<SelectItem value="junior">Junior</SelectItem>
												<SelectItem value="mid">Mid-Level</SelectItem>
												<SelectItem value="senior">Senior</SelectItem>
											</SelectContent>
										</Select>
									</div>
								</div>
								<Button onClick={handleGenerateInterviewQuestions} className="w-full">
									Generate Questions
								</Button>
								{subscriptionTier === "free" && (
									<p className="text-xs text-muted-foreground text-center">Free tier: 5 questions. Upgrade for unlimited questions.</p>
								)}
							</CardContent>
						</Card>

						{interviewQuestions.length > 0 && (
							<>
								<Card>
									<CardHeader>
										<CardTitle>Practice Questions</CardTitle>
										<CardDescription>Use the STAR method: Situation, Task, Action, Result</CardDescription>
									</CardHeader>
									<CardContent className="space-y-4">
										{interviewQuestions.map((question, index) => (
											<div key={index} className="border rounded-lg p-4">
												<div className="flex items-start gap-3">
													<div className="flex items-center justify-center size-8 rounded-full bg-primary text-primary-foreground font-bold shrink-0">
														{index + 1}
													</div>
													<div className="flex-1">
														<p className="font-medium mb-2">{question}</p>
														<Textarea placeholder="Prepare your answer using the STAR method..." rows={3} className="mt-2" />
													</div>
												</div>
											</div>
										))}
									</CardContent>
								</Card>

								<Card>
									<CardHeader>
										<CardTitle>STAR Method Guide</CardTitle>
									</CardHeader>
									<CardContent>
										<div className="space-y-3">
											<div className="flex gap-3">
												<Badge className="shrink-0">S</Badge>
												<div>
													<p className="font-medium">Situation</p>
													<p className="text-sm text-muted-foreground">Set the context and background</p>
												</div>
											</div>
											<div className="flex gap-3">
												<Badge className="shrink-0">T</Badge>
												<div>
													<p className="font-medium">Task</p>
													<p className="text-sm text-muted-foreground">Explain what needed to be done</p>
												</div>
											</div>
											<div className="flex gap-3">
												<Badge className="shrink-0">A</Badge>
												<div>
													<p className="font-medium">Action</p>
													<p className="text-sm text-muted-foreground">Describe the steps you took</p>
												</div>
											</div>
											<div className="flex gap-3">
												<Badge className="shrink-0">R</Badge>
												<div>
													<p className="font-medium">Result</p>
													<p className="text-sm text-muted-foreground">Share the outcome and what you learnt</p>
												</div>
											</div>
										</div>
									</CardContent>
								</Card>
							</>
						)}
					</div>
				)}
			</main>

			{/* Upgrade Dialog */}
			<AlertDialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
				<AlertDialogContent>
					<AlertDialogHeader>
						<AlertDialogTitle>Upgrade to Premium</AlertDialogTitle>
						<AlertDialogDescription>
							You've reached the free tier limit for this feature. Upgrade to Premium for just £3/month to get:
						</AlertDialogDescription>
					</AlertDialogHeader>
					<ul className="space-y-2 my-4">
						<li className="flex items-center gap-2 text-sm">
							<CheckCircle2 className="size-4 text-green-600" />
							Unlimited CV builds and optimisations
						</li>
						<li className="flex items-center gap-2 text-sm">
							<CheckCircle2 className="size-4 text-green-600" />
							Full LinkedIn profile optimisation
						</li>
						<li className="flex items-center gap-2 text-sm">
							<CheckCircle2 className="size-4 text-green-600" />
							Complete apprenticeship mode features
						</li>
						<li className="flex items-center gap-2 text-sm">
							<CheckCircle2 className="size-4 text-green-600" />
							Unlimited interview preparation questions
						</li>
					</ul>
					<AlertDialogFooter>
						<AlertDialogCancel>Maybe Later</AlertDialogCancel>
						<AlertDialogAction onClick={() => { setSubscriptionTier("paid"); setShowUpgradeDialog(false); }}>
							Upgrade Now - £3/month
						</AlertDialogAction>
					</AlertDialogFooter>
				</AlertDialogContent>
			</AlertDialog>
		</div>
	);
}
