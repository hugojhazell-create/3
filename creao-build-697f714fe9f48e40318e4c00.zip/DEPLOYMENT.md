# TruePath Deployment Guide

This guide will help you deploy your TruePath application as a live website.

## Quick Start - Easiest Options

### Option 1: Deploy to Vercel (Recommended - Free)

Vercel is the easiest and fastest way to deploy your React application.

**Steps:**

1. **Install Git (if not already installed)**
   ```bash
   git --version
   # If not installed, download from https://git-scm.com/
   ```

2. **Initialize Git Repository**
   ```bash
   cd /home/user/vite-template
   git init
   git add .
   git commit -m "Initial commit - TruePath application"
   ```

3. **Push to GitHub**
   - Go to https://github.com/new
   - Create a new repository (name it "truepath" or any name you prefer)
   - Don't initialize with README (your project already has files)
   - Run these commands:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/truepath.git
   git branch -M main
   git push -u origin main
   ```

4. **Deploy on Vercel**
   - Go to https://vercel.com/signup
   - Sign up with your GitHub account
   - Click "Add New Project"
   - Import your GitHub repository
   - Vercel will auto-detect Vite settings
   - Click "Deploy"
   - Your site will be live at: `https://truepath-XXXXX.vercel.app`

**Done! Your website is now live!**

---

### Option 2: Deploy to Netlify (Also Free)

**Steps:**

1. **Prepare the same Git repository** (follow steps 1-3 from Option 1)

2. **Deploy on Netlify**
   - Go to https://app.netlify.com/signup
   - Sign up with your GitHub account
   - Click "Add new site" → "Import an existing project"
   - Choose GitHub and select your repository
   - Build settings (auto-detected):
     - Build command: `npm run build`
     - Publish directory: `dist`
   - Click "Deploy site"
   - Your site will be live at: `https://truepath-XXXXX.netlify.app`

---

### Option 3: Deploy to Cloudflare Pages (Free)

**Steps:**

1. **Prepare Git repository** (steps 1-3 from Option 1)

2. **Deploy on Cloudflare Pages**
   - Go to https://dash.cloudflare.com/sign-up/pages
   - Sign up and connect your GitHub account
   - Click "Create a project"
   - Select your repository
   - Build settings:
     - Framework preset: Vite
     - Build command: `npm run build`
     - Build output directory: `dist`
   - Click "Save and Deploy"
   - Your site will be live at: `https://truepath.pages.dev`

---

## Option 4: Manual Deployment (Any Web Host)

If you have your own web hosting (shared hosting, VPS, etc.):

**Steps:**

1. **Build the Application**
   ```bash
   cd /home/user/vite-template
   npm run build
   ```
   This creates a `dist` folder with your static website files.

2. **Upload to Your Server**
   - Upload everything inside the `dist` folder to your web server
   - Common paths:
     - cPanel: `public_html/`
     - Apache: `/var/www/html/`
     - Nginx: `/usr/share/nginx/html/`

3. **Configure Server** (if needed)
   - For single-page apps, configure your server to redirect all routes to `index.html`
   - See "Server Configuration" section below

---

## Environment Variables (Optional)

If you need to add API keys or backend URLs later:

1. Create a `.env` file in the project root:
   ```env
   VITE_API_URL=https://your-api.com
   VITE_STRIPE_KEY=your_stripe_public_key
   ```

2. Access in your code:
   ```typescript
   const apiUrl = import.meta.env.VITE_API_URL;
   ```

3. On Vercel/Netlify/Cloudflare:
   - Go to your project settings
   - Add environment variables in the dashboard
   - Redeploy

---

## Custom Domain

### On Vercel:
1. Go to Project Settings → Domains
2. Add your custom domain (e.g., `truepath.com`)
3. Update your domain's DNS records as instructed
4. SSL certificate is automatically provisioned

### On Netlify:
1. Go to Site Settings → Domain Management
2. Click "Add custom domain"
3. Follow DNS configuration instructions
4. SSL is automatic

### On Cloudflare Pages:
1. Go to Custom Domains
2. Add your domain
3. DNS is automatically configured if domain is on Cloudflare
4. SSL is automatic

---

## Server Configuration (for Manual Deployment)

### Apache (.htaccess)
Create a `.htaccess` file in your web root:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

### Nginx
Add to your nginx configuration:
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

---

## Post-Deployment Checklist

- [ ] Website loads correctly at your URL
- [ ] Login/Signup pages work
- [ ] All navigation links work
- [ ] CV Builder, Optimizer, LinkedIn, Apprenticeship, Interview Prep all accessible
- [ ] Logout works correctly
- [ ] Mobile responsive design looks good
- [ ] SSL certificate is active (https://)
- [ ] Custom domain configured (if applicable)

---

## Troubleshooting

**Problem: Blank page after deployment**
- Check browser console for errors (F12)
- Verify build completed successfully
- Check that `dist` folder was uploaded completely

**Problem: 404 on page refresh**
- Configure server for SPA routing (see Server Configuration above)
- For Vercel/Netlify/Cloudflare, this is automatic

**Problem: Assets not loading**
- Check that all files in `dist/assets` are uploaded
- Verify file permissions on server (644 for files, 755 for directories)

---

## Next Steps After Deployment

1. **Connect Real Backend API**
   - Replace mock authentication in `src/lib/auth-context.tsx`
   - Add real API endpoints for CV generation, optimization, etc.

2. **Integrate Stripe for Payments**
   - Add Stripe integration for £3/month subscriptions
   - Use the existing subscription tier logic

3. **Add Analytics**
   - Google Analytics
   - Vercel Analytics (free on Vercel)
   - Plausible or other privacy-friendly options

4. **Set Up Database**
   - Use the existing ORM files in `src/sdk/database/orm/`
   - Connect to PostgreSQL, MySQL, or your preferred database
   - Implement user data persistence

5. **Add Email Functionality**
   - Welcome emails for new signups
   - Password reset functionality
   - CV delivery via email

---

## Need Help?

- **Vercel Documentation**: https://vercel.com/docs
- **Netlify Documentation**: https://docs.netlify.com
- **Cloudflare Pages Documentation**: https://developers.cloudflare.com/pages
- **Vite Documentation**: https://vitejs.dev/guide/

Your TruePath application is production-ready and can be deployed in under 10 minutes using any of these platforms!
