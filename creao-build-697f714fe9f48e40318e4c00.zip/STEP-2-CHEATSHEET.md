# Step 2 Cheat Sheet - Push to GitHub

## 🎯 Goal
Upload your code from your computer to GitHub.

---

## ⚡ Quick Steps

### 1. Create GitHub Repository
- Go to: **https://github.com/new**
- Name: `truepath`
- Make it Public or Private
- ❌ Don't check any boxes
- Click "Create repository"

### 2. Copy Commands from GitHub
After creating, GitHub shows you commands that look like:
```bash
git remote add origin https://github.com/YOUR_USERNAME/truepath.git
git branch -M main
git push -u origin main
```

### 3. Run Commands in Terminal
```bash
# Make sure you're in the project folder
cd /home/user/vite-template

# Copy-paste all 3 commands from GitHub, one at a time:
git remote add origin https://github.com/YOUR_USERNAME/truepath.git
git branch -M main
git push -u origin main
```

### 4. Verify It Worked
- Visit: `https://github.com/YOUR_USERNAME/truepath`
- You should see all your files! ✅

---

## 🔑 Key Points

**Replace YOUR_USERNAME:**
- If your GitHub username is "johnsmith"
- Use: `https://github.com/johnsmith/truepath.git`

**Copy from GitHub:**
- GitHub fills in your username automatically
- Easiest method: click the copy button (📋) on GitHub
- Paste in terminal

**Where to run commands:**
- In your terminal/command prompt
- Make sure you're in: `/home/user/vite-template`

---

## ❓ Troubleshooting

**"Permission denied"**
```bash
# You need to authenticate with GitHub
# Use a Personal Access Token as your password
# Or use: gh auth login
```

**"Repository not found"**
```bash
# Check spelling and username
# Try removing and re-adding:
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/truepath.git
```

**"Already exists"**
```bash
# Just push:
git push -u origin main
```

---

## ✅ Success = You Can See Your Code on GitHub

Visit `https://github.com/YOUR_USERNAME/truepath` and you'll see:
- All your project files
- Your commit message
- 159 files uploaded

**Next:** Deploy to Vercel (Step 3) - See QUICKSTART.md

---

## 📋 Command Reference

```bash
# Check what remote is connected
git remote -v

# See branch name
git branch

# Check status
git status

# View commit history
git log --oneline
```

---

**Need more help?** Read:
- **STEP-2-DETAILED-GUIDE.md** - Complete explanation
- **VISUAL-STEP-BY-STEP.md** - Visual diagrams
- **QUICKSTART.md** - Full deployment guide
